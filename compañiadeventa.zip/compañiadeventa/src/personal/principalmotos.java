
package personal;


public class principalmotos {
  public static void main(String [] args){
      ventasanuales op= new ventasanuales();
  op.calcularsalario();
  op.conmision();
  op.imprimir();
  }  
}
